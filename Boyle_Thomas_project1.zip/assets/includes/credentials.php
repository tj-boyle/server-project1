<?php
    /**
    *   connect.php
    *   An include file for proper credentials to connect to the proper database
    *   
    *   @author Thomas Boyle <tjb2597@rit.edu>   
    *   @version 1.0
    *   
    *
    */
    $username = 'root';
    $password = 'CHipohomework2';

?>