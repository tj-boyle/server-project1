<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, maximum-scale=1.0, minimum-scale=1.0, initial-scale=1.0" />
    <title>Project 1</title>
    <link rel="stylesheet" type="text/css" href="./assets/stylesheets/base.css"/>
    <link rel="stylesheet" type="text/css" href="./assets/stylesheets/skeleton.css"/>
    <link rel="stylesheet" type="text/css" href="./assets/stylesheets/layout.css"/>
    
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
    <script src="assets/javascript/jPages.js"></script>
    <!--[if IE]>
      <link href="/stylesheets/ie.css" media="screen, projection" rel="stylesheet" type="text/css" />
    <![endif]-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,800' rel='stylesheet' type='text/css'>
</head>